This file contains instructions on how to compile my code using gcc to create an executable file called movies_by_year.
Run the following commands with the following assumptions:
 - $ is the line indicator thing in bash 
 - the moviesProcessor.c file is in the same directory as the test files 
 - you are in the same directory as the test and moviesProcessor.c files
 - (otherwise, the path will need to be specified)
$ gcc -o movies_by_year ./moviesProcessor.c
$ ./movies_by_year
