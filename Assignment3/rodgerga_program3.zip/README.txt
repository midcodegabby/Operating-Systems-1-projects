This file contains instructions on how to compile my code using gcc to create an executable file called smallsh.
Run the following commands with the following assumptions:
 - $ is the line indicator thing in bash 
 - the smallsh.c file is in the same directory as the test file
 - you are in the same directory as the test and smallsh.c files
 - (otherwise, the path will need to be specified)
$ gcc -o smallsh smallsh.c
$ ./smallsh
